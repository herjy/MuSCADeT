var searchData=
[
  ['actg',['actg',['../namespace_mu_s_c_a_de_t_1_1pca__ring__spectrum.html#a9cd239ef49f7b4944ce1b00176f8a79f',1,'MuSCADeT::pca_ring_spectrum']]]
];
