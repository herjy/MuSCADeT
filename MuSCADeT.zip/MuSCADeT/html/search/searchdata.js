var indexSectionsWithContent =
{
  0: "ailmnprwx",
  1: "m",
  2: "ailmprw",
  3: "ilnrx"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Functions",
  3: "Variables"
};

