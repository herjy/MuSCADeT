var searchData=
[
  ['colour_5fsubtraction',['colour_subtraction',['../namespace_mu_s_c_a_de_t_1_1colour__subtraction.html',1,'MuSCADeT']]],
  ['mca',['MCA',['../namespace_mu_s_c_a_de_t_1_1_m_c_a.html',1,'MuSCADeT']]],
  ['mk_5fpca',['mk_pca',['../namespace_mu_s_c_a_de_t_1_1mk__pca.html',1,'MuSCADeT']]],
  ['pca_5fring_5fspectrum',['pca_ring_spectrum',['../namespace_mu_s_c_a_de_t_1_1pca__ring__spectrum.html',1,'MuSCADeT']]],
  ['wave_5ftransform',['wave_transform',['../namespace_mu_s_c_a_de_t_1_1wave__transform.html',1,'MuSCADeT']]]
];
