var searchData=
[
  ['colour_5fsubtraction',['colour_subtraction',['../namespace_m2_c_a_d_1_1colour__subtraction.html',1,'M2CAD']]],
  ['mca',['MCA',['../namespace_m2_c_a_d_1_1_m_c_a.html',1,'M2CAD']]],
  ['mk_5fpca',['mk_pca',['../namespace_m2_c_a_d_1_1mk__pca.html',1,'M2CAD']]],
  ['pca_5fring_5fspectrum',['pca_ring_spectrum',['../namespace_m2_c_a_d_1_1pca__ring__spectrum.html',1,'M2CAD']]],
  ['wave_5ftransform',['wave_transform',['../namespace_m2_c_a_d_1_1wave__transform.html',1,'M2CAD']]]
];
