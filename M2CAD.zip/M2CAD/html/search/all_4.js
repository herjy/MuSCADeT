var searchData=
[
  ['noise',['noise',['../namespace_m2_c_a_d_1_1pca__ring__spectrum.html#a0099a36ef2970012b78d6fc716d6707b',1,'M2CAD::pca_ring_spectrum']]]
];
