var searchData=
[
  ['pca_5finitialise',['PCA_initialise',['../namespace_m2_c_a_d_1_1_m_c_a.html#a0f9be8aba58fe7d82c24e7a6d45994d4',1,'M2CAD::MCA']]],
  ['pca_5flines',['pca_lines',['../namespace_m2_c_a_d_1_1pca__ring__spectrum.html#a479084a8b61b9a6467679eaef5c28791',1,'M2CAD::pca_ring_spectrum']]],
  ['pca_5fring_5fspectrum',['pca_ring_spectrum',['../namespace_m2_c_a_d_1_1pca__ring__spectrum.html#a25a564be4dcce1a5bd11bfe0e9a845bd',1,'M2CAD::pca_ring_spectrum']]]
];
