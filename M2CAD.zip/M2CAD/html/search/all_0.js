var searchData=
[
  ['actg',['actg',['../namespace_m2_c_a_d_1_1pca__ring__spectrum.html#ae8afef014a141f6cca1235ba3ce9d68f',1,'M2CAD::pca_ring_spectrum']]]
];
