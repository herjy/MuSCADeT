var searchData=
[
  ['xy',['xy',['../namespace_m2_c_a_d_1_1pca__ring__spectrum.html#af837db34b918fb0d5628dfc8f8b7a48c',1,'M2CAD::pca_ring_spectrum']]]
];
