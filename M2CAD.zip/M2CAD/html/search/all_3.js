var searchData=
[
  ['colour_5fsubtraction',['colour_subtraction',['../namespace_m2_c_a_d_1_1colour__subtraction.html',1,'M2CAD']]],
  ['mad',['MAD',['../namespace_m2_c_a_d_1_1_m_c_a.html#afaeada192d060b003600f552e2af3c7c',1,'M2CAD::MCA']]],
  ['make_5fcolour_5fsub',['make_colour_sub',['../namespace_m2_c_a_d_1_1colour__subtraction.html#a5245941117b7e24995d94ef5dd58489a',1,'M2CAD::colour_subtraction']]],
  ['mca',['MCA',['../namespace_m2_c_a_d_1_1_m_c_a.html',1,'M2CAD']]],
  ['mk_5fpca',['mk_pca',['../namespace_m2_c_a_d_1_1mk__pca.html#abb3d496bf48b739ac4726d25242b85d4',1,'M2CAD::mk_pca']]],
  ['mk_5fpca',['mk_pca',['../namespace_m2_c_a_d_1_1mk__pca.html',1,'M2CAD']]],
  ['mmca',['mMCA',['../namespace_m2_c_a_d_1_1_m_c_a.html#a70cf3f2d05b496e8b8d38a347f264f3b',1,'M2CAD::MCA']]],
  ['mom',['MOM',['../namespace_m2_c_a_d_1_1_m_c_a.html#af1254da44bc945707bb434f75729153b',1,'M2CAD::MCA']]],
  ['mr_5ffilter',['mr_filter',['../namespace_m2_c_a_d_1_1_m_c_a.html#a1ee3f1fb24ae77e4c1e0dd63bfaf6055',1,'M2CAD::MCA']]],
  ['pca_5fring_5fspectrum',['pca_ring_spectrum',['../namespace_m2_c_a_d_1_1pca__ring__spectrum.html',1,'M2CAD']]],
  ['wave_5ftransform',['wave_transform',['../namespace_m2_c_a_d_1_1wave__transform.html',1,'M2CAD']]]
];
