var searchData=
[
  ['specs',['specs',['../namespace_m2_c_a_d_1_1_m_c_a.html#a0e7205ee560dfb04474bf7a7d77eb749',1,'M2CAD::MCA']]]
];
