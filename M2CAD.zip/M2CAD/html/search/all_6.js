var searchData=
[
  ['rec_5fpca',['rec_pca',['../namespace_m2_c_a_d_1_1mk__pca.html#abc53cb1e458fc6cc11fd1a6313f4dbc1',1,'M2CAD::mk_pca']]],
  ['reweight',['reweight',['../namespace_m2_c_a_d_1_1_m_c_a.html#aa68c55991adc66d364c4baf8fa9eabec',1,'M2CAD::MCA']]]
];
