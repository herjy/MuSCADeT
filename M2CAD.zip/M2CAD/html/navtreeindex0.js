var NAVTREEINDEX0 =
{
".html":[0,0,0],
"index.html":[],
"namespace_m2_c_a_d_1_1_m_c_a.html":[0,0,0,1],
"namespace_m2_c_a_d_1_1colour__subtraction.html":[0,0,0,0],
"namespace_m2_c_a_d_1_1mk__pca.html":[0,0,0,2],
"namespace_m2_c_a_d_1_1pca__ring__spectrum.html":[0,0,0,3],
"namespace_m2_c_a_d_1_1wave__transform.html":[0,0,0,4],
"namespacemembers.html":[0,1,0],
"namespacemembers_func.html":[0,1,1],
"namespacemembers_vars.html":[0,1,2],
"namespaces.html":[0,0],
"pages.html":[]
};
