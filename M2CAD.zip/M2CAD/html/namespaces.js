var namespaces =
[
    [ "M2CAD", null, [
      [ "colour_subtraction", "namespace_m2_c_a_d_1_1colour__subtraction.html", null ],
      [ "MCA", "namespace_m2_c_a_d_1_1_m_c_a.html", null ],
      [ "mk_pca", "namespace_m2_c_a_d_1_1mk__pca.html", null ],
      [ "pca_ring_spectrum", "namespace_m2_c_a_d_1_1pca__ring__spectrum.html", null ],
      [ "wave_transform", "namespace_m2_c_a_d_1_1wave__transform.html", null ]
    ] ]
];