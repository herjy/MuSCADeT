import MCA
import colour_subtraction
import mk_pca
import pca_ring_spectrum
import wave_transform
